#include "settings.h"
#include "ui_settings.h"
#include "mainwindow.h"
#include <QFile>
#include <QTextStream>

Settings::Settings(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Settings)
{
    ui->setupUi(this);

}

Settings::~Settings()
{
    delete ui;
}

void Settings::on_Back_clicked()
{
    MainWindow *k=new MainWindow;
    k->show();
    this->close();
}

void Settings::on_Save_clicked()
{
    QString filename="config.txt";
    QFile eFile(filename);
    if(eFile.open(QFile::WriteOnly|QFile::Text)){
        QTextStream out(&eFile);
        out<<"DIFFICULTY: "     <<ui->Difficulty->text()<<endl;
        out<<"FOV: "            <<ui->FOV->text()<<endl;
        out<<"FRAMERATE: "      <<ui->FramRateCap<<endl;
        out<<"CAP: "            <<ui->Cap->text()<<endl;
        out<<"DISPLAYFPS: "     <<ui->DisplayFPS->text()<<endl;
        out<<"FULLSCREEN: "     <<ui->FullScreen->text()<<endl;
        out<<"WINDOWED: "       <<ui->Windowed->text()<<endl;
        out<<"RESOLUTION: "     <<ui->Resolution->text()<<endl;
    }
    QTextStream out(&eFile);
    out<<filename<<endl;

    eFile.close();

}
